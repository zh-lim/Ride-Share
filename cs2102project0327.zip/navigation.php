﻿  <div id="nav" class="box">
    <ul>
      <li <?php echo $active0; ?>><a href="index.php">Home</a></li>
      <li <?php echo $active1; ?>><a href="ridePosting.php">Offer Rides</a></li>
      <li <?php echo $active2; ?>><a href="rideHistory.php">Driver's Record</a></li>
      <li <?php echo $active4; ?>><a href="passengerRecord.php">Passenger's Record</a></li>
    </ul>
    <hr class="noscreen" />
  </div>