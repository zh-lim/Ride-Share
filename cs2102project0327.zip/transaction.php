<?php
	include("header.php");	
        echo"welcome!";
?>

<?php     
$content=$_POST['content'];
$driver=$content[0];
$startTime=$content[1];
$date=$content[2];

$query1="SELECT p.name FROM passenger p WHERE p.rstart='$startTime' AND p.rdriver='$driver' AND p.rdate='$date';";
$result1 = pg_query($query1) or die('Error1!');
$arr=pg_fetch_all($result1);
$arrsize=sizeof($arr);

$query2="SELECT r.cost FROM ride r where r.date='$date' and r.starttime='$startTime' and r.driver='$driver';";
$result2 = pg_query($query2) or die('Error2!'.pg_last_error());
$costarr=pg_fetch_array($result2);
$cost=$costarr['cost'];

for ($i=0;$i<$arrsize;$i++)
{
echo "$i";
echo '<br/>';
$element=$arr[$i]["name"];

$query3="SELECT p.status FROM passenger p where p.name='".$element."' AND p.rstart='".$startTime."' AND p.rdriver='".$driver."' AND p.rdate='".$date."';";
$result3=pg_query($query3)or die('cannot find status');
$sarr=pg_fetch_array($result3);
$selement=$sarr['status'];
echo $cost;
echo '<br/>';

if($selement=='C')
{
echo"paid";
echo '<br/>';
//mark ride status as F
$query4="UPDATE ride SET status='F' where date='$date' and starttime='$startTime' and driver='$driver';";
$result4=pg_query($query4)or die('cannot find ride');

//deduct and add balance
$query5="UPDATE account set balance =balance -'$cost' where username='$element' ;";
$result5=pg_query($query5)or die('cannot deduct balance');

$query6="UPDATE account set balance =balance +'$cost' where username='$driver' ;";
$result6=pg_query($query6)or die('cannot add balance');
}
else 
{
echo "$element alreay paid";
echo '<br/>';
}

};//end of for loop

echo "<form action='rideDetails.php' method='POST'><input type = 'submit' name='whatever' value = 'Get Back'/></form>";

?>
