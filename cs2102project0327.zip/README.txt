How do you get updated to latest version:
1. Backup whatever you have created. Then delete them all from postgres
2. Create a new database in postgres, use Bean_Schema.sql to create all new tables.
3. Use AccountData.sql, CarData.sql, PassengerData.sql, RideData.sql to add in raw data. Default password for every account in the account table is "cs2102".
4. Copy all php files and folders into folder ".../htdocs/"
5. Change the database name and password in Config.php accordingly.
6. Try run index.php. If cannot, contact +6582085650.


Some things to do:
Account balance cannot update while logged, need to log out and re-login.
Index page the words and pictures.
Search and book rides not here yet.(If you can check balance before booking rides, it will prevent negative balance.)
The neigborhood dropdown list is incomplete.(like Changi, Bukit Timah, Sentosa, Clark Quae...)