insert into passenger values ('anniechapman1991','14:00','xiexin2011','2016-03-30','P','2016-03-26 21:12:30');
insert into passenger values ('davidchapman1989','14:00','xiexin2011','2016-03-30','P','2016-03-26 21:15:30');
insert into passenger values ('tcy','14:00','xiexin2011','2016-03-30','P','2016-03-26 21:40:30');
insert into passenger values ('glee','14:00','xiexin2011','2016-03-30','P','2016-03-26 21:55:30');