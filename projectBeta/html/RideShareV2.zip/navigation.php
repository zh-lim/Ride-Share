﻿  <div id="nav" class="box">
    <ul>
      <li <?php if (!isset($active0)) $active0=""; echo $active0; ?>><a href="index.php">Home</a></li>
      <li <?php if (!isset($active1)) $active1=""; echo $active1; ?>><a href="ridePosting.php">Offer Rides</a></li>
      <li <?php if (!isset($active2)) $active2=""; echo $active2; ?>><a href="rideHistory.php">Rides Offered</a></li>
      <li <?php if (!isset($active4)) $active4=""; echo $active4; ?>><a href="passengerRecord.php">Request History</a></li>
    </ul>
    <hr class="noscreen" />
  </div>