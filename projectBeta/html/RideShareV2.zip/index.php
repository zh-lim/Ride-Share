﻿<?php
	include("header.php");
	
?>
<title>Car Pooling</title>
<body>
<div id="layout">
<?php 
	$active0 = "id='active'";
	$pageTitle = "Car Pooling";
	include("banner.php");
	include("navigation.php");
?>
  <div id="container" class="box">
    <div id="obsah" class="content box">
      <div class="in">
        <div id="new-article">
          <div id="corner">
            <h2><a href="http://all-free-download.com/free-website-templates/">Lorem ipsum</a></h2>
            <div class="f-left article-img"><img src="tmp/image.jpg" alt="" />
              <div></div>
            </div>
            <p class="f-left"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. <a href="http://all-free-download.com/free-website-templates/" class="more">MORE</a></p>
            <div class="clear"></div>
          </div>
        </div>
        <div class="article">
          <h2><a href="http://all-free-download.com/free-website-templates/">Lorem ipsum</a></h2>
          <div class="f-left article-img"><img src="tmp/image.jpg" alt="" />
            <div></div>
          </div>
          <p class="f-left"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. <a href="http://all-free-download.com/free-website-templates/" class="more">MORE</a></p>
          <div class="clear"></div>
        </div>
        <div class="article">
          <h2><a href="http://all-free-download.com/free-website-templates/">Lorem ipsum</a></h2>
          <div class="f-left article-img"><img src="tmp/image.jpg" alt="" />
            <div></div>
          </div>
          <p class="f-left"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. <a href="http://all-free-download.com/free-website-templates/" class="more">MORE</a></p>
          <div class="clear"></div>
        </div>
        <div class="article">
          <h2><a href="http://all-free-download.com/free-website-templates/">Lorem ipsum</a></h2>
          <div class="f-left article-img"><img src="tmp/image.jpg" alt="" />
            <div></div>
          </div>
          <p class="f-left"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. <a href="http://all-free-download.com/free-website-templates/" class="more">MORE</a></p>
          <div class="clear"></div>
        </div>
        <div class="article">
          <h2><a href="http://all-free-download.com/free-website-templates/">Lorem ipsum</a></h2>
          <div class="f-left article-img"><img src="tmp/image.jpg" alt="" />
            <div></div>
          </div>
          <p class="f-left"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. <a href="http://all-free-download.com/free-website-templates/" class="more">MORE</a></p>
          <div class="clear"></div>
        </div>
        <a href="http://all-free-download.com/free-website-templates/" class="older">&laquo; Older articles</a> </div>
    </div>
    <div id="panel-right" class="box panel">
		<div id="bottom">
			<?php include("sidebar.php")?>
		</div>
    </div>
  </div>
</div>
<div id="footer">
  <div id="foot">
    <div id="page-bottom"> <a href="#header">Go up</a> </div>
    <p class="f-left">&copy; 2008 - <a href="http://all-free-download.com/free-website-templates/">SimpleEvent</a></p>
    <p class="f-right"><a href="http://www.tvorimestranky.cz" id="webdesign">Webdesign</a>: <a href="http://www.tvorimestranky.cz">TvorimeStranky.cz</a> | Sponsored by: <a href="http://www.topas-tachlovice.cz/topas-tachlovice.aspx">Tachlovice</a></p>
  </div>
</div>
<div align=center>This template  downloaded form <a href='http://all-free-download.com/free-website-templates/'>free website templates</a></div></body>
</html>
