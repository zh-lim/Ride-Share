﻿  <div id="header">
    <h1 id="logo"><?php echo $pageTitle; ?></h1>
    <span id="slogan">Sharing Is Caring ...</span>
    <hr class="noscreen" />
    <div id="quicknav"> <a href="index.php">Home</a> <a href="index.php">Contact</a> <a href="index.php">Sitemap</a> </div>
    <div id="search">
      <form href="search.php" method="post">
        <fieldset>
        <input type="text" id="phrase" name="phrase" value="search phrase" onfocus="if(this.value=='search phrase')this.value=''" />
        <input type="submit" id="submit" value="SEARCH" />
        </fieldset>
      </form>
    </div>
  </div>
  <hr class="noscreen" />
